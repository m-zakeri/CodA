bool foo(int x, int y)
{
return ((y <= 8 * sin (0.2*x+7)+4) && (y<= sqrt(x)+8) && (x<= 16-y))
}